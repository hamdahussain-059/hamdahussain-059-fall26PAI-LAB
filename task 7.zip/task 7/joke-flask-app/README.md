# 🎭 Ha! — Flask Random Joke App

A Flask web app that fetches jokes from the **Official Joke API** and displays them in a polished UI.

---

## 📁 Project Structure

```
joke-flask-app/
├── app.py                   # Flask backend + API routes
├── requirements.txt         # Python dependencies
├── templates/
│   └── index.html           # Jinja2 HTML template
└── static/
    ├── css/
    │   └── style.css        # Styles
    └── js/
        └── main.js          # Frontend JS (calls Flask routes)
```

---

## ⚡ Quick Start

### 1. Install dependencies
```bash
pip install flask requests
# or
pip install -r requirements.txt
```

### 2. Run the app
```bash
python app.py
```

### 3. Open in browser
```
http://127.0.0.1:5000
```

---

## 🔄 How It Works (Data Flow)

```
Browser  →  fetch("/joke?type=general")
           ↓
         Flask (app.py)
           ↓
         requests.get("https://official-joke-api.appspot.com/jokes/general/random")
           ↓
         JSON response  →  back to browser  →  displayed in UI
```

---

## 🛣️ Flask Routes

| Route | Method | Description |
|-------|--------|-------------|
| `/` | GET | Renders the main page |
| `/joke?type=<category>` | GET | Fetches one random joke |
| `/joke/ten?type=<category>` | GET | Fetches 10 jokes at once |

**Available categories:** `general`, `programming`, `knock-knock`, `dark`

---

## 🧪 Test the API directly
```bash
curl http://127.0.0.1:5000/joke?type=programming
```

Expected response:
```json
{
  "success": true,
  "id": 37,
  "type": "programming",
  "setup": "What's a computer's favorite snack?",
  "punchline": "Microchips!"
}
```

---

## 📦 Dependencies

- **Flask** – Web framework
- **requests** – HTTP client to call the external joke API
- **Official Joke API** – Free, no key required (`https://official-joke-api.appspot.com`)
