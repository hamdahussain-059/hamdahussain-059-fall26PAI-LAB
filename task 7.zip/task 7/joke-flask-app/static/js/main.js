/**
 * main.js  –  Fetches jokes from our Flask backend (/joke route),
 *             which in turn calls the Official Joke API.
 *
 * Data flow:
 *   Browser  →  fetch("/joke?type=…")  →  Flask app.py  →  Official Joke API
 */

const jokeBtn      = document.getElementById("jokeBtn");
const jokeCard     = document.getElementById("jokeCard");
const jokeSetup    = document.getElementById("jokeSetup");
const jokePunchline= document.getElementById("jokePunchline");
const loader       = document.getElementById("loader");
const placeholder  = document.getElementById("placeholder");
const revealBtn    = document.getElementById("revealBtn");
const divider      = document.getElementById("divider");
const categoryBadge= document.getElementById("categoryBadge");
const errorMsg     = document.getElementById("errorMsg");
const counter      = document.getElementById("counter");
const countEl      = document.getElementById("count");
const routeDisplay = document.getElementById("routeDisplay");
const chips        = document.querySelectorAll(".chip");

let selectedType = "general";
let jokeCount    = 0;

// ── Category chip selection ─────────────────────────────────
chips.forEach(chip => {
  chip.addEventListener("click", () => {
    chips.forEach(c => c.classList.remove("active"));
    chip.classList.add("active");
    selectedType = chip.dataset.type;
  });
});

// ── Reset card to blank state ───────────────────────────────
function resetCard() {
  jokeCard.classList.remove("show-setup", "show-punchline");
  jokeSetup.textContent    = "";
  jokePunchline.textContent = "";
  divider.style.display    = "none";
  categoryBadge.style.display = "none";
  revealBtn.classList.add("hidden");
  errorMsg.classList.add("hidden");
  errorMsg.textContent = "";
}

// ── Fetch joke from Flask backend ──────────────────────────
async function fetchJoke() {
  resetCard();
  jokeBtn.disabled = true;
  placeholder.classList.add("hidden");
  loader.classList.remove("hidden");

  const flaskRoute = `/joke?type=${selectedType}`;
  routeDisplay.textContent = flaskRoute;         // show the route being called

  try {
    // 👇 This calls OUR Flask route, not the external API directly
    const res  = await fetch(flaskRoute);
    const data = await res.json();

    loader.classList.add("hidden");

    if (!data.success) {
      showError(data.error || "Something went wrong.");
      return;
    }

    // Populate card
    jokeSetup.textContent     = data.setup;
    jokePunchline.textContent = data.punchline;
    categoryBadge.textContent = data.type || selectedType;
    categoryBadge.style.display = "block";
    divider.style.display     = "block";

    // Animate setup in
    jokeCard.classList.add("show-setup");

    // Show reveal button
    revealBtn.classList.remove("hidden");

    // Update counter
    jokeCount++;
    countEl.textContent = jokeCount;
    counter.classList.remove("hidden");

  } catch (err) {
    loader.classList.add("hidden");
    showError("Network error – is Flask running?");
  } finally {
    jokeBtn.disabled = false;
  }
}

// ── Reveal punchline ────────────────────────────────────────
revealBtn.addEventListener("click", () => {
  revealBtn.classList.add("hidden");
  jokeCard.classList.add("show-punchline");
});

// ── Main button ─────────────────────────────────────────────
jokeBtn.addEventListener("click", fetchJoke);

// ── Helper ──────────────────────────────────────────────────
function showError(msg) {
  placeholder.classList.remove("hidden");
  placeholder.textContent = "";
  errorMsg.textContent    = "⚠️ " + msg;
  errorMsg.classList.remove("hidden");
}
