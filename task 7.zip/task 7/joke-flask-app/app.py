from flask import Flask, render_template, jsonify, request
import requests

app = Flask(__name__)
BASE_URL = "https://official-joke-api.appspot.com"

CATEGORIES = ["general", "programming", "knock-knock", "dark"]


@app.route("/")
def index():
    """Render the main page."""
    return render_template("index.html", categories=CATEGORIES)


@app.route("/joke")
def get_joke():
    """
    Fetch a random joke from the Official Joke API.
    Query param: ?type=general|programming|knock-knock|dark
    """
    joke_type = request.args.get("type", "general")
    if joke_type not in CATEGORIES:
        joke_type = "general"

    try:
        response = requests.get(
            f"{BASE_URL}/jokes/{joke_type}/random",
            timeout=5
        )
        response.raise_for_status()         
        data = response.json()
        joke = data[0] if isinstance(data, list) else data

        return jsonify({
            "success": True,
            "id":       joke.get("id"),
            "type":     joke.get("type"),
            "setup":    joke.get("setup"),
            "punchline": joke.get("punchline"),
        })

    except requests.exceptions.ConnectionError:
        return jsonify({"success": False, "error": "Could not connect to joke API."}), 503
    except requests.exceptions.Timeout:
        return jsonify({"success": False, "error": "Request timed out."}), 504
    except requests.exceptions.HTTPError as e:
        return jsonify({"success": False, "error": str(e)}), 500
    except Exception as e:
        return jsonify({"success": False, "error": "Unexpected error: " + str(e)}), 500


@app.route("/joke/ten")
def get_ten_jokes():
    """Fetch 10 random jokes of a given type."""
    joke_type = request.args.get("type", "general")
    if joke_type not in CATEGORIES:
        joke_type = "general"

    try:
        response = requests.get(
            f"{BASE_URL}/jokes/{joke_type}/ten",
            timeout=5
        )
        response.raise_for_status()
        jokes = response.json()
        return jsonify({"success": True, "jokes": jokes})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500

if __name__ == "__main__":
    app.run(debug=True)
