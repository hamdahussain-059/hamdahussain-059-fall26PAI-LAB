import cv2
import numpy as np
import os
import threading
from flask import Flask, render_template, Response, request, jsonify, redirect, url_for
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['MAX_CONTENT_LENGTH'] = 500 * 1024 * 1024  # 500MB max

ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'mkv', 'webm'}

# Global state
state = {
    'count': 0,
    'crossed_ids': set(),
    'current_video': None,
    'is_streaming': False,
    'line_position': 0.5,  # 0.0 to 1.0 (fraction of frame height)
    'line_direction': 'horizontal',  # 'horizontal' or 'vertical'
    'target_class': 'all',
    'frame_width': 640,
    'frame_height': 480,
    'fps': 0,
    'total_frames': 0,
    'current_frame': 0,
    'detections_this_frame': 0,
}

# YOLO setup
net = None
output_layers = None
classes = []
use_yolo = False

COCO_CLASSES = [
    "person", "bicycle", "car", "motorbike", "aeroplane", "bus", "train", "truck",
    "boat", "traffic light", "fire hydrant", "stop sign", "parking meter", "bench",
    "bird", "cat", "dog", "horse", "sheep", "cow", "elephant", "bear", "zebra",
    "giraffe", "backpack", "umbrella", "handbag", "tie", "suitcase", "frisbee",
    "skis", "snowboard", "sports ball", "kite", "baseball bat", "baseball glove",
    "skateboard", "surfboard", "tennis racket", "bottle", "wine glass", "cup",
    "fork", "knife", "spoon", "bowl", "banana", "apple", "sandwich", "orange",
    "broccoli", "carrot", "hot dog", "pizza", "donut", "cake", "chair", "sofa",
    "pottedplant", "bed", "diningtable", "toilet", "tvmonitor", "laptop", "mouse",
    "remote", "keyboard", "cell phone", "microwave", "oven", "toaster", "sink",
    "refrigerator", "book", "clock", "vase", "scissors", "teddy bear", "hair drier",
    "toothbrush"
]

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def load_yolo():
    """Try to load YOLOv4-tiny weights. Falls back to simple blob detection."""
    global net, output_layers, classes, use_yolo
    
    weights_path = 'yolov4-tiny.weights'
    cfg_path = 'yolov4-tiny.cfg'
    names_path = 'coco.names'
    
    if os.path.exists(weights_path) and os.path.exists(cfg_path):
        try:
            net = cv2.dnn.readNet(weights_path, cfg_path)
            layer_names = net.getLayerNames()
            output_layers = [layer_names[i - 1] for i in net.getUnconnectedOutLayers()]
            if os.path.exists(names_path):
                with open(names_path, 'r') as f:
                    classes = [line.strip() for line in f.readlines()]
            else:
                classes = COCO_CLASSES
            use_yolo = True
            print("✅ YOLOv4-tiny loaded successfully")
        except Exception as e:
            print(f"⚠️  YOLO load failed: {e}. Using fallback detector.")
            use_yolo = False
    else:
        print("ℹ️  YOLO weights not found. Using fallback motion/blob detector.")
        use_yolo = False

def detect_objects_yolo(frame):
    """Detect objects using YOLO."""
    height, width = frame.shape[:2]
    blob = cv2.dnn.blobFromImage(frame, 0.00392, (416, 416), (0, 0, 0), True, crop=False)
    net.setInput(blob)
    outs = net.forward(output_layers)
    
    class_ids, confidences, boxes = [], [], []
    
    for out in outs:
        for detection in out:
            scores = detection[5:]
            class_id = np.argmax(scores)
            confidence = scores[class_id]
            if confidence > 0.4:
                cx = int(detection[0] * width)
                cy = int(detection[1] * height)
                w = int(detection[2] * width)
                h = int(detection[3] * height)
                x = int(cx - w / 2)
                y = int(cy - h / 2)
                boxes.append([x, y, w, h])
                confidences.append(float(confidence))
                class_ids.append(class_id)
    
    indices = cv2.dnn.NMSBoxes(boxes, confidences, 0.4, 0.3)
    
    results = []
    if len(indices) > 0:
        for i in indices.flatten():
            x, y, w, h = boxes[i]
            cx, cy = x + w // 2, y + h // 2
            label = classes[class_ids[i]] if class_ids[i] < len(classes) else "object"
            results.append({
                'bbox': (x, y, w, h),
                'center': (cx, cy),
                'label': label,
                'confidence': confidences[i],
                'id': i
            })
    return results

def detect_objects_fallback(frame, prev_frame=None, bg_subtractor=None):
    """Fallback: detect moving blobs using background subtraction."""
    results = []
    
    if bg_subtractor is not None:
        fg_mask = bg_subtractor.apply(frame)
        kernel = cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (5, 5))
        fg_mask = cv2.morphologyEx(fg_mask, cv2.MORPH_OPEN, kernel)
        fg_mask = cv2.dilate(fg_mask, kernel, iterations=2)
        
        contours, _ = cv2.findContours(fg_mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        
        obj_id = 0
        for contour in contours:
            area = cv2.contourArea(contour)
            if area > 500:
                x, y, w, h = cv2.boundingRect(contour)
                cx, cy = x + w // 2, y + h // 2
                results.append({
                    'bbox': (x, y, w, h),
                    'center': (cx, cy),
                    'label': 'object',
                    'confidence': 0.8,
                    'id': obj_id
                })
                obj_id += 1
    
    return results

def check_line_crossing(obj_id, center, prev_centers, line_pos, direction, frame_w, frame_h):
    """Check if an object crossed the counting line."""
    if obj_id not in prev_centers:
        return False
    
    prev_cx, prev_cy = prev_centers[obj_id]
    cx, cy = center
    
    if direction == 'horizontal':
        line_y = int(line_pos * frame_h)
        if (prev_cy < line_y and cy >= line_y) or (prev_cy >= line_y and cy < line_y):
            return True
    else:
        line_x = int(line_pos * frame_w)
        if (prev_cx < line_x and cx >= line_x) or (prev_cx >= line_x and cx < line_x):
            return True
    
    return False

def generate_frames(video_path):
    """Generator that yields processed video frames."""
    global state
    
    cap = cv2.VideoCapture(video_path)
    if not cap.isOpened():
        return
    
    state['frame_width'] = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    state['frame_height'] = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    state['fps'] = cap.get(cv2.CAP_PROP_FPS) or 30
    state['total_frames'] = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
    state['count'] = 0
    state['crossed_ids'] = set()
    state['is_streaming'] = True
    state['current_frame'] = 0
    
    bg_subtractor = cv2.createBackgroundSubtractorMOG2(
        history=100, varThreshold=40, detectShadows=False
    )
    
    prev_centers = {}
    frame_count = 0
    
    # Color palette for bounding boxes
    COLORS = [
        (0, 255, 127),   # Spring green
        (0, 191, 255),   # Deep sky blue
        (255, 165, 0),   # Orange
        (255, 0, 128),   # Hot pink
        (160, 32, 240),  # Purple
        (0, 255, 255),   # Cyan
    ]
    
    while state['is_streaming']:
        ret, frame = cap.read()
        if not ret:
            # Loop video
            cap.set(cv2.CAP_PROP_POS_FRAMES, 0)
            bg_subtractor = cv2.createBackgroundSubtractorMOG2(
                history=100, varThreshold=40, detectShadows=False
            )
            prev_centers = {}
            state['count'] = 0
            state['crossed_ids'] = set()
            continue
        
        frame_count += 1
        state['current_frame'] = frame_count
        
        h, w = frame.shape[:2]
        target_w = 854
        target_h = int(h * target_w / w)
        frame = cv2.resize(frame, (target_w, target_h))
        h, w = frame.shape[:2]
        
        line_pos = state['line_position']
        direction = state['line_direction']
        target_class = state['target_class']
        
        # Detect objects
        if use_yolo:
            detections = detect_objects_yolo(frame)
        else:
            detections = detect_objects_fallback(frame, bg_subtractor=bg_subtractor)
        
        # Filter by class if needed
        if target_class != 'all' and use_yolo:
            detections = [d for d in detections if d['label'] == target_class]
        
        state['detections_this_frame'] = len(detections)
        
        # Draw counting line
        if direction == 'horizontal':
            line_y = int(line_pos * h)
            cv2.line(frame, (0, line_y), (w, line_y), (0, 255, 200), 2)
            # Dashed effect overlay
            for i in range(0, w, 30):
                cv2.line(frame, (i, line_y), (min(i+15, w), line_y), (255, 255, 255), 1)
        else:
            line_x = int(line_pos * w)
            cv2.line(frame, (line_x, 0), (line_x, h), (0, 255, 200), 2)
            for i in range(0, h, 30):
                cv2.line(frame, (line_x, i), (line_x, min(i+15, h)), (255, 255, 255), 1)
        
        current_centers = {}
        
        for obj in detections:
            x, y, bw, bh = obj['bbox']
            cx, cy = obj['center']
            obj_id = obj['id']
            label = obj['label']
            conf = obj['confidence']
            
            color = COLORS[obj_id % len(COLORS)]
            
            # Check crossing
            unique_key = f"{frame_count}_{obj_id}"
            if check_line_crossing(obj_id, (cx, cy), prev_centers, line_pos, direction, w, h):
                if unique_key not in state['crossed_ids']:
                    state['crossed_ids'].add(unique_key)
                    state['count'] += 1
            
            current_centers[obj_id] = (cx, cy)
            
            # Draw bounding box with rounded corners style
            cv2.rectangle(frame, (x, y), (x + bw, y + bh), color, 2)
            
            # Corner accents
            corner_len = min(15, bw // 4, bh // 4)
            cv2.line(frame, (x, y), (x + corner_len, y), color, 3)
            cv2.line(frame, (x, y), (x, y + corner_len), color, 3)
            cv2.line(frame, (x + bw, y), (x + bw - corner_len, y), color, 3)
            cv2.line(frame, (x + bw, y), (x + bw, y + corner_len), color, 3)
            cv2.line(frame, (x, y + bh), (x + corner_len, y + bh), color, 3)
            cv2.line(frame, (x, y + bh), (x, y + bh - corner_len), color, 3)
            cv2.line(frame, (x + bw, y + bh), (x + bw - corner_len, y + bh), color, 3)
            cv2.line(frame, (x + bw, y + bh), (x + bw, y + bh - corner_len), color, 3)
            
            # Label background
            label_text = f"{label} {conf:.0%}"
            (tw, th), _ = cv2.getTextSize(label_text, cv2.FONT_HERSHEY_SIMPLEX, 0.5, 1)
            cv2.rectangle(frame, (x, y - th - 8), (x + tw + 6, y), color, -1)
            cv2.putText(frame, label_text, (x + 3, y - 4),
                        cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 0, 0), 1)
            
            # Center dot
            cv2.circle(frame, (cx, cy), 4, color, -1)
        
        prev_centers = current_centers
        
        # HUD Overlay
        overlay = frame.copy()
        cv2.rectangle(overlay, (0, 0), (220, 80), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.6, frame, 0.4, 0, frame)
        
        cv2.putText(frame, f"COUNT: {state['count']}", (12, 32),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.9, (0, 255, 200), 2)
        cv2.putText(frame, f"IN FRAME: {len(detections)}", (12, 58),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.55, (200, 200, 200), 1)
        cv2.putText(frame, f"FRAME: {frame_count}", (12, 74),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.4, (150, 150, 150), 1)
        
        # Line label
        detector_label = "YOLO" if use_yolo else "MOTION"
        cv2.putText(frame, f"[{detector_label}] COUNTING LINE", 
                    (w // 2 - 80, int(line_pos * h) - 8 if direction == 'horizontal' else 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.45, (0, 255, 200), 1)
        
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 85])
        yield (b'--frame\r\nContent-Type: image/jpeg\r\n\r\n' + buffer.tobytes() + b'\r\n')
    
    cap.release()
    state['is_streaming'] = False

# Load YOLO at startup
load_yolo()

@app.route('/')
def index():
    return render_template('index.html', 
                           classes=['all'] + COCO_CLASSES,
                           use_yolo=use_yolo)

@app.route('/upload', methods=['POST'])
def upload_video():
    if 'video' not in request.files:
        return jsonify({'error': 'No file provided'}), 400
    
    file = request.files['video']
    if file.filename == '':
        return jsonify({'error': 'No file selected'}), 400
    
    if not allowed_file(file.filename):
        return jsonify({'error': 'File type not allowed'}), 400
    
    state['is_streaming'] = False
    
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    state['current_video'] = filepath
    state['count'] = 0
    
    return jsonify({'success': True, 'filename': filename})

@app.route('/start_stream', methods=['POST'])
def start_stream():
    data = request.json or {}
    state['line_position'] = float(data.get('line_position', 0.5))
    state['line_direction'] = data.get('line_direction', 'horizontal')
    state['target_class'] = data.get('target_class', 'all')
    state['count'] = 0
    state['crossed_ids'] = set()
    return jsonify({'success': True})

@app.route('/stop_stream', methods=['POST'])
def stop_stream():
    state['is_streaming'] = False
    return jsonify({'success': True})

@app.route('/video_feed')
def video_feed():
    if not state['current_video'] or not os.path.exists(state['current_video']):
        return "No video loaded", 400
    return Response(
        generate_frames(state['current_video']),
        mimetype='multipart/x-mixed-replace; boundary=frame'
    )

@app.route('/stats')
def get_stats():
    return jsonify({
        'count': state['count'],
        'detections_this_frame': state['detections_this_frame'],
        'is_streaming': state['is_streaming'],
        'current_frame': state['current_frame'],
        'total_frames': state['total_frames'],
        'fps': state['fps'],
        'use_yolo': use_yolo,
    })

@app.route('/reset', methods=['POST'])
def reset_counter():
    state['count'] = 0
    state['crossed_ids'] = set()
    return jsonify({'success': True})

if __name__ == '__main__':
    os.makedirs('uploads', exist_ok=True)
    app.run(debug=True, threaded=True)