# ObjectFlow — AI Object Counter

A Flask web app for real-time object counting in videos using line-crossing detection.

## Features
- **Live video streaming** to the browser via MJPEG
- **Line-crossing counter** — horizontal or vertical, fully adjustable
- **YOLOv4-tiny** for class-specific detection (car, person, bottle, etc.)
- **Motion-based fallback** if YOLO weights aren't present
- **Clean dashboard UI** with live stats overlay

---

## Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run (motion detection mode — no download needed)
```bash
python app.py
```
Open http://localhost:5000

---

## Upgrade to YOLO (Recommended)

Download these 3 files into the project root:

```bash
# Config file (~24 KB)
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/AlexeyAB/darknet/master/cfg/yolov4-tiny cfg" -OutFile "yolov4-tiny.cfg"

# Class names
Invoke-WebRequest -Uri "https://raw.githubusercontent.com/AlexeyAB/darknet/master/data/coco.names" -OutFile "coco.names"

# Weights (~23 MB)
Invoke-WebRequest -Uri "https://github.com/AlexeyAB/darknet/releases/download/darknet_yolo_v4_pre/yolov4-tiny.weights" -OutFile "yolov4-tiny.weights"
```



Then restart the app — it will auto-detect the weights.

---

## How It Works

```
Video Upload → OpenCV Frame Extraction
     ↓
YOLO/Motion Detector → Bounding Boxes + Centers
     ↓
Line Crossing Check (per-frame center vs. line threshold)
     ↓
Counter Increments → Streamed to Browser via MJPEG
```

## Project Structure
```
object-counter/
├── app.py              ← Flask backend + detection logic
├── templates/
│   └── index.html      ← Frontend dashboard
├── requirements.txt
├── uploads/            ← Uploaded videos (auto-created)
├── yolov4-tiny.weights ← (download separately)
├── yolov4-tiny.cfg     ← (download separately)
└── coco.names          ← (download separately)
```

## Supported Classes (YOLO mode)
person, bicycle, car, motorbike, bus, truck, bottle, cup, chair, and 70+ more COCO classes.

## Counting Logic
Each detected object gets an ID per frame. When its center point crosses the counting line (comparing current vs. previous frame position), the counter increments once per crossing event.